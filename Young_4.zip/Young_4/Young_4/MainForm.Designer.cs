﻿namespace Young_4
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimeMTB = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pickUpRadioButton = new System.Windows.Forms.RadioButton();
            this.dineInRadioButton = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.customerInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.phoneNumberMTB = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lastNameTB = new System.Windows.Forms.TextBox();
            this.firstNameTB = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.toppingsLabel = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.toppingsLB = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.breadCB = new System.Windows.Forms.ComboBox();
            this.largeLabel = new System.Windows.Forms.Label();
            this.mediumLabel = new System.Windows.Forms.Label();
            this.smallLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.largeRadioButton = new System.Windows.Forms.RadioButton();
            this.mediumRadioButton = new System.Windows.Forms.RadioButton();
            this.smallRadioButton = new System.Windows.Forms.RadioButton();
            this.sandwichPriceLabel = new System.Windows.Forms.Label();
            this.salesTaxTotalLabel = new System.Windows.Forms.Label();
            this.totalPriceLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.customerInfoGroupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 32F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(191, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(356, 146);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sam\'s Finest Roast Beef Sandwiches";
            // 
            // dateTimeMTB
            // 
            this.dateTimeMTB.Location = new System.Drawing.Point(40, 203);
            this.dateTimeMTB.Mask = "00/00/0000 90:00";
            this.dateTimeMTB.Name = "dateTimeMTB";
            this.dateTimeMTB.Size = new System.Drawing.Size(100, 20);
            this.dateTimeMTB.TabIndex = 2;
            this.dateTimeMTB.ValidatingType = typeof(System.DateTime);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Date and Time of Order";
            // 
            // pickUpRadioButton
            // 
            this.pickUpRadioButton.AutoSize = true;
            this.pickUpRadioButton.Location = new System.Drawing.Point(51, 253);
            this.pickUpRadioButton.Name = "pickUpRadioButton";
            this.pickUpRadioButton.Size = new System.Drawing.Size(63, 17);
            this.pickUpRadioButton.TabIndex = 4;
            this.pickUpRadioButton.TabStop = true;
            this.pickUpRadioButton.Text = "Pick Up";
            this.pickUpRadioButton.UseVisualStyleBackColor = true;
            // 
            // dineInRadioButton
            // 
            this.dineInRadioButton.AutoSize = true;
            this.dineInRadioButton.Location = new System.Drawing.Point(51, 277);
            this.dineInRadioButton.Name = "dineInRadioButton";
            this.dineInRadioButton.Size = new System.Drawing.Size(59, 17);
            this.dineInRadioButton.TabIndex = 5;
            this.dineInRadioButton.TabStop = true;
            this.dineInRadioButton.Text = "Dine In";
            this.dineInRadioButton.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Pick Up or Dine In?";
            // 
            // customerInfoGroupBox
            // 
            this.customerInfoGroupBox.Controls.Add(this.phoneNumberMTB);
            this.customerInfoGroupBox.Controls.Add(this.label6);
            this.customerInfoGroupBox.Controls.Add(this.label5);
            this.customerInfoGroupBox.Controls.Add(this.label4);
            this.customerInfoGroupBox.Controls.Add(this.lastNameTB);
            this.customerInfoGroupBox.Controls.Add(this.firstNameTB);
            this.customerInfoGroupBox.Location = new System.Drawing.Point(180, 184);
            this.customerInfoGroupBox.Name = "customerInfoGroupBox";
            this.customerInfoGroupBox.Size = new System.Drawing.Size(367, 116);
            this.customerInfoGroupBox.TabIndex = 7;
            this.customerInfoGroupBox.TabStop = false;
            this.customerInfoGroupBox.Text = "Customer Information";
            // 
            // phoneNumberMTB
            // 
            this.phoneNumberMTB.Location = new System.Drawing.Point(138, 90);
            this.phoneNumberMTB.Mask = "(999) 000-0000";
            this.phoneNumberMTB.Name = "phoneNumberMTB";
            this.phoneNumberMTB.Size = new System.Drawing.Size(100, 20);
            this.phoneNumberMTB.TabIndex = 6;
            this.phoneNumberMTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Last Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "First Name";
            // 
            // lastNameTB
            // 
            this.lastNameTB.Location = new System.Drawing.Point(138, 53);
            this.lastNameTB.Name = "lastNameTB";
            this.lastNameTB.Size = new System.Drawing.Size(100, 20);
            this.lastNameTB.TabIndex = 1;
            // 
            // firstNameTB
            // 
            this.firstNameTB.Location = new System.Drawing.Point(138, 19);
            this.firstNameTB.Name = "firstNameTB";
            this.firstNameTB.Size = new System.Drawing.Size(100, 20);
            this.firstNameTB.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.toppingsLabel);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.toppingsLB);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.breadCB);
            this.groupBox1.Controls.Add(this.largeLabel);
            this.groupBox1.Controls.Add(this.mediumLabel);
            this.groupBox1.Controls.Add(this.smallLabel);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.largeRadioButton);
            this.groupBox1.Controls.Add(this.mediumRadioButton);
            this.groupBox1.Controls.Add(this.smallRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 306);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(532, 162);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Order";
            // 
            // toppingsLabel
            // 
            this.toppingsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toppingsLabel.Location = new System.Drawing.Point(465, 13);
            this.toppingsLabel.Name = "toppingsLabel";
            this.toppingsLabel.Size = new System.Drawing.Size(61, 36);
            this.toppingsLabel.TabIndex = 11;
            this.toppingsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(369, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "Toppings Desired";
            // 
            // toppingsLB
            // 
            this.toppingsLB.FormattingEnabled = true;
            this.toppingsLB.Location = new System.Drawing.Point(382, 61);
            this.toppingsLB.Name = "toppingsLB";
            this.toppingsLB.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.toppingsLB.Size = new System.Drawing.Size(144, 95);
            this.toppingsLB.TabIndex = 9;
            this.toppingsLB.SelectedIndexChanged += new System.EventHandler(this.toppingsLB_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(220, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(113, 13);
            this.label11.TabIndex = 8;
            this.label11.Text = "Type of Bread Desired";
            // 
            // breadCB
            // 
            this.breadCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.breadCB.FormattingEnabled = true;
            this.breadCB.Location = new System.Drawing.Point(223, 40);
            this.breadCB.Name = "breadCB";
            this.breadCB.Size = new System.Drawing.Size(121, 21);
            this.breadCB.TabIndex = 7;
            // 
            // largeLabel
            // 
            this.largeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.largeLabel.Location = new System.Drawing.Point(133, 112);
            this.largeLabel.Name = "largeLabel";
            this.largeLabel.Size = new System.Drawing.Size(57, 23);
            this.largeLabel.TabIndex = 6;
            this.largeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mediumLabel
            // 
            this.mediumLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mediumLabel.Location = new System.Drawing.Point(133, 66);
            this.mediumLabel.Name = "mediumLabel";
            this.mediumLabel.Size = new System.Drawing.Size(57, 23);
            this.mediumLabel.TabIndex = 5;
            this.mediumLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // smallLabel
            // 
            this.smallLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.smallLabel.Location = new System.Drawing.Point(133, 26);
            this.smallLabel.Name = "smallLabel";
            this.smallLabel.Size = new System.Drawing.Size(57, 23);
            this.smallLabel.TabIndex = 4;
            this.smallLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Sandwich Size";
            // 
            // largeRadioButton
            // 
            this.largeRadioButton.AutoSize = true;
            this.largeRadioButton.Location = new System.Drawing.Point(23, 118);
            this.largeRadioButton.Name = "largeRadioButton";
            this.largeRadioButton.Size = new System.Drawing.Size(87, 17);
            this.largeRadioButton.TabIndex = 2;
            this.largeRadioButton.TabStop = true;
            this.largeRadioButton.Text = "Large (12 in.)";
            this.largeRadioButton.UseVisualStyleBackColor = true;
            this.largeRadioButton.CheckedChanged += new System.EventHandler(this.largeRadioButton_CheckedChanged);
            // 
            // mediumRadioButton
            // 
            this.mediumRadioButton.AutoSize = true;
            this.mediumRadioButton.Location = new System.Drawing.Point(23, 72);
            this.mediumRadioButton.Name = "mediumRadioButton";
            this.mediumRadioButton.Size = new System.Drawing.Size(91, 17);
            this.mediumRadioButton.TabIndex = 1;
            this.mediumRadioButton.TabStop = true;
            this.mediumRadioButton.Text = "Medium (9 in.)";
            this.mediumRadioButton.UseVisualStyleBackColor = true;
            this.mediumRadioButton.CheckedChanged += new System.EventHandler(this.mediumRadioButton_CheckedChanged);
            // 
            // smallRadioButton
            // 
            this.smallRadioButton.AutoSize = true;
            this.smallRadioButton.Location = new System.Drawing.Point(23, 32);
            this.smallRadioButton.Name = "smallRadioButton";
            this.smallRadioButton.Size = new System.Drawing.Size(79, 17);
            this.smallRadioButton.TabIndex = 0;
            this.smallRadioButton.TabStop = true;
            this.smallRadioButton.Text = "Small (6 in.)";
            this.smallRadioButton.UseVisualStyleBackColor = true;
            this.smallRadioButton.CheckedChanged += new System.EventHandler(this.smallRadioButton_CheckedChanged);
            // 
            // sandwichPriceLabel
            // 
            this.sandwichPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sandwichPriceLabel.Location = new System.Drawing.Point(109, 509);
            this.sandwichPriceLabel.Name = "sandwichPriceLabel";
            this.sandwichPriceLabel.Size = new System.Drawing.Size(57, 23);
            this.sandwichPriceLabel.TabIndex = 9;
            this.sandwichPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // salesTaxTotalLabel
            // 
            this.salesTaxTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesTaxTotalLabel.Location = new System.Drawing.Point(252, 509);
            this.salesTaxTotalLabel.Name = "salesTaxTotalLabel";
            this.salesTaxTotalLabel.Size = new System.Drawing.Size(57, 23);
            this.salesTaxTotalLabel.TabIndex = 10;
            this.salesTaxTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalPriceLabel
            // 
            this.totalPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalPriceLabel.Location = new System.Drawing.Point(394, 509);
            this.totalPriceLabel.Name = "totalPriceLabel";
            this.totalPriceLabel.Size = new System.Drawing.Size(57, 23);
            this.totalPriceLabel.TabIndex = 11;
            this.totalPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(104, 485);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Sandwich Price";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(232, 485);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Total Sales Tax";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(391, 485);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Total Price";
            // 
            // taxLabel
            // 
            this.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxLabel.Location = new System.Drawing.Point(319, 485);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(45, 21);
            this.taxLabel.TabIndex = 15;
            this.taxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(556, 24);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveOrderToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // saveOrderToolStripMenuItem
            // 
            this.saveOrderToolStripMenuItem.Name = "saveOrderToolStripMenuItem";
            this.saveOrderToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveOrderToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.saveOrderToolStripMenuItem.Text = "&Save Order";
            this.saveOrderToolStripMenuItem.ToolTipText = "Click here to save your order";
            this.saveOrderToolStripMenuItem.Click += new System.EventHandler(this.saveOrderToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.ToolTipText = "Click here to exit the order form";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearOrderToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // clearOrderToolStripMenuItem
            // 
            this.clearOrderToolStripMenuItem.Name = "clearOrderToolStripMenuItem";
            this.clearOrderToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.clearOrderToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.clearOrderToolStripMenuItem.Text = "&Clear Order";
            this.clearOrderToolStripMenuItem.ToolTipText = "Click here to clear the order form";
            this.clearOrderToolStripMenuItem.Click += new System.EventHandler(this.clearOrderToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.ToolTipText = "Click here for an about me";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Young_4.Properties.Resources.sandwich_620;
            this.pictureBox1.Location = new System.Drawing.Point(5, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(180, 154);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 569);
            this.Controls.Add(this.taxLabel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.totalPriceLabel);
            this.Controls.Add(this.salesTaxTotalLabel);
            this.Controls.Add(this.sandwichPriceLabel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.customerInfoGroupBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dineInRadioButton);
            this.Controls.Add(this.pickUpRadioButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimeMTB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sam\'s Finest Roast Beef Sandwiches";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.customerInfoGroupBox.ResumeLayout(false);
            this.customerInfoGroupBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox dateTimeMTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton pickUpRadioButton;
        private System.Windows.Forms.RadioButton dineInRadioButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox customerInfoGroupBox;
        private System.Windows.Forms.MaskedTextBox phoneNumberMTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox lastNameTB;
        private System.Windows.Forms.TextBox firstNameTB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label toppingsLabel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox toppingsLB;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox breadCB;
        private System.Windows.Forms.Label largeLabel;
        private System.Windows.Forms.Label mediumLabel;
        private System.Windows.Forms.Label smallLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton largeRadioButton;
        private System.Windows.Forms.RadioButton mediumRadioButton;
        private System.Windows.Forms.RadioButton smallRadioButton;
        private System.Windows.Forms.Label sandwichPriceLabel;
        private System.Windows.Forms.Label salesTaxTotalLabel;
        private System.Windows.Forms.Label totalPriceLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

