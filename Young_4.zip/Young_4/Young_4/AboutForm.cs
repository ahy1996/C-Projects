﻿//Programmer: Aaron Young
//Project: Assignment #4
//Class: About Form
//Date: 11/26/2017


using System;
using System.Windows.Forms;

namespace Young_4
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

        //Create click event for the exit button
        private void aboutExitButton_Click(object sender, EventArgs e)
        {
            DialogResult selection;
            selection = MessageBox.Show("Are you sure you wish to exit the form?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            //take appropriate action based on the user's selection
            if (selection == DialogResult.Yes)
            {
                this.Close();
            }
        }

    }
}
