﻿//Programmer: Aaron Young
//Project: Assignment #4
//Class: Main Form
//Date: 11/26/2017


using System;
using System.Windows.Forms;
using System.IO; //Add namespace to allow use of StreamReader and StreamWriter

namespace Young_4
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        //Declare class level constants
        private const decimal SMALL_SANDWICH = 4.95m;
        private const decimal MEDIUM_SANDWICH = 6.95m;
        private const decimal LARGE_SANDWICH = 8.95m;
        private const decimal TOPPINGS = 0.25m;
        private const decimal SALES_TAX_RATE = 0.07m;
        //declare class level variables
        decimal subtotal = 0m;
        decimal salesTax;
        decimal totalPrice;
        string ordertype;
        string sandwichsize;


        //Executes when the form is first loaded
        private void MainForm_Load(object sender, EventArgs e)
        {
            //Display current date and time
            dateTimeMTB.Text = DateTime.Now.ToString("MM/dd/yyyy hh:mm");


            //Call custom method to populte combo and list boxes
            PopulateBoxes();

            //Populate the price labels
            smallLabel.Text = SMALL_SANDWICH.ToString("c");
            mediumLabel.Text = MEDIUM_SANDWICH.ToString("c");
            largeLabel.Text = LARGE_SANDWICH.ToString("c");
            taxLabel.Text = SALES_TAX_RATE.ToString("p");
            toppingsLabel.Text = TOPPINGS.ToString("c") + " Each";

            //Set white bread as default
            breadCB.SelectedItem = "White";

            //Set Pick up as default
            pickUpRadioButton.Checked = true;

            //Set medium as default 
            mediumRadioButton.Checked = true;

            
        }

        //Custom method to load data from external files
        private void PopulateBoxes()
        {
            try //Assure that file is readable
            {
                StreamReader inputFile; //Declare StreamReader object

                inputFile = File.OpenText("Breads.txt");
                while (!inputFile.EndOfStream)
                {
                    //read a line and add it to combo box
                    breadCB.Items.Add(inputFile.ReadLine());
                }
                inputFile.Close();

                inputFile = File.OpenText("Toppings.txt");
                while (!inputFile.EndOfStream)
                {
                    //read a line and add to list box
                    toppingsLB.Items.Add(inputFile.ReadLine());
                }
                //close input file
                inputFile.Close();
            }
            catch (Exception ex)
            {
                //display message if error occurs
                MessageBox.Show(ex.Message);
            }
        }

            //Create update totals custom method
            private void UpdateTotals()
            {
                if (smallRadioButton.Checked)
                    subtotal = SMALL_SANDWICH;
                if (mediumRadioButton.Checked)
                    subtotal = MEDIUM_SANDWICH;
                if (largeRadioButton.Checked)
                    subtotal = LARGE_SANDWICH;

            //Loop through items 
            for (int count = 0; count < toppingsLB.Items.Count; count++)
            {
                //Use GetSelected method to determine what is selected
                if (toppingsLB.GetSelected(count))
                {
                    subtotal += TOPPINGS; //Add topping price for each topping chosen
                }
            }
                 //Calc totals
                salesTax = subtotal * SALES_TAX_RATE;
                totalPrice = subtotal + salesTax;

            //Display totals in labels
            sandwichPriceLabel.Text = subtotal.ToString("c");
            salesTaxTotalLabel.Text = salesTax.ToString("c");
            totalPriceLabel.Text = totalPrice.ToString("c");
            }
            
            //Create a custom method for clearing the form to its start up state
            private void ClearForm()
            {
            firstNameTB.Text = "";
            lastNameTB.Text = "";
            phoneNumberMTB.Text = "";
            pickUpRadioButton.Checked = true;
            mediumRadioButton.Checked = true;
            breadCB.SelectedItem = "White";
            firstNameTB.Focus();
            toppingsLB.ClearSelected();
            dateTimeMTB.Text = DateTime.Now.ToString("MM/dd/yyyy hh:mm");
            }

        //Update totals when small sandwich is clicked
        private void smallRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        //Update totals when medium sandwich is clicked
        private void mediumRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        //Update totals when large sandwich is clicked
        private void largeRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        //Update totals for each topping
        private void toppingsLB_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        //Clear the form 
        private void clearOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        //Save the order form
        private void saveOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Display error if name or phone number boxes are empty
            if (firstNameTB.Text=="" || lastNameTB.Text=="" || phoneNumberMTB.MaskCompleted==false)
            {
                MessageBox.Show("All customer information must be entered.", "Missing Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                firstNameTB.Focus();
            }

            else
            {
                

                //Determine and set value to be included in output file
                if(pickUpRadioButton.Checked)
                {
                    ordertype = "Pick Up";
                }
                else
                {
                    ordertype = "Dine In";
                }

                //Determine and set value for size of sandwich to be included in output file
                if(smallRadioButton.Checked)
                {
                    sandwichsize = "Small (6 in.)";
                }
                if(mediumRadioButton.Checked)
                {
                    sandwichsize = "Medium (9 in.)";
                }
                if(largeRadioButton.Checked)
                {
                    sandwichsize = "Large (12 in.)";
                }


                try
                {
                    //Write order Info to an output file
                    StreamWriter outputFile;
                    outputFile = File.AppendText("OrderData.txt");
                    outputFile.WriteLine("Sam's Finest Roast Beef Sandwiches");
                    outputFile.WriteLine();
                    outputFile.WriteLine("ORDER DATE:" + dateTimeMTB.Text);
                    outputFile.WriteLine("CUSTOMER NAME:" + firstNameTB.Text + " " + lastNameTB.Text);
                    outputFile.WriteLine("CUSTOMER PHONE NUMBER:" + phoneNumberMTB.Text);
                    outputFile.WriteLine("PICK UP OR DINE IN?:" + ordertype);
                    outputFile.WriteLine("SANDWICH SIZE:" + sandwichsize);
                    outputFile.WriteLine("TYPE OF BREAD:" + breadCB.Text);
                    outputFile.WriteLine("TOPPINGS:");
                    //Loop through listbox items and add to file
                    for (int count = 0; count < toppingsLB.Items.Count; count++)
                    {
                        //Use GetSelected method to determine what is selected
                        if (toppingsLB.GetSelected(count))
                        {
                            outputFile.WriteLine("    " + toppingsLB.Items[count]);
                        }
                    }
                    outputFile.WriteLine("TOTAL BEFORE TAX:" + sandwichPriceLabel.Text);
                    outputFile.WriteLine("TOTAL SALES TAX:" + salesTaxTotalLabel.Text);
                    outputFile.WriteLine("TOTAL PRICE:" + totalPriceLabel.Text);
                    outputFile.WriteLine();
                    outputFile.WriteLine();
                    outputFile.Close();
                }
                catch (Exception ex)
                {
                    //Display error message if error occurs while writing to file
                    MessageBox.Show(ex.Message);

                   
                }
                //Clear the form once it is saved
                ClearForm();
            }
        }

        //Exit the form click event
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult selection;
            selection = MessageBox.Show("Are you sure you wish to exit the form?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            //take appropriate action based on the user's selection
            if(selection==DialogResult.Yes)
            {
                this.Close();
            }
        }

        //Create the about menu item click event
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Create an instance of the AboutForm Class
            AboutForm myAboutForm = new AboutForm();

            //Display AboutForm instance as a modal form
            myAboutForm.ShowDialog();
        }
    }
          }

        
    

