﻿//Programmer: Aaron Young
//Project: Assignment #3
// Due: 11/3/2017
// Date 10/30/2017

using System;
using System.Windows.Forms;
using System.IO;


namespace Young_3
{
    public partial class Form1 : Form
    {
        //Declare class-level constants
        private const decimal BOAT_PRICE = 100000m;
        private const decimal OPTION_PRICE = 1000m;
        private const decimal DELIVERY_PRICE = 3000m;
        private decimal totalPrice = 0m;
        

        public Form1()
        {
            InitializeComponent();
        }

        // Execute upon startup
        private void Form1_Load(object sender, System.EventArgs e)
        {
            //Display current date from system clock
            dateMTB.Text = DateTime.Now.ToString("MM/dd/yyyy");

            //Inboard set as default
            inboardRadioButton.Checked = true;

            //Set total price equal to 100000
            totalPrice = BOAT_PRICE;

            //Set default prices
            addonLabel.Text = OPTION_PRICE.ToString("c");
            boatPriceTB.Text = BOAT_PRICE.ToString("c");
            shippingOptionLabel.Text = "Expedited Shipping Is An Additional " + DELIVERY_PRICE.ToString("c");
            orderTotalLabel.Text = totalPrice.ToString("c");

            //Populate the combo box
            PopulateComboBox();

            //Populate List Box
            PopulateListBox();

            //Set default to Aquanova
            boatComboBox.SelectedItem = "Aquanova";

            

        }

        //Create custom method for populating the boat model combo box
        private void PopulateComboBox()
        {
            try //Assure File is readable
            {
                StreamReader inputFile; //Declare StreamReader use for reading file
                boatComboBox.Items.Clear(); //Clear items in the combo box
                inputFile = File.OpenText("Models.txt"); //Open file in default folder
                while (!inputFile.EndOfStream) //Verify that more data needs to be read
                {
                    //Read a line and add to list box
                    boatComboBox.Items.Add(inputFile.ReadLine());
                }
                inputFile.Close(); //Close input file
            }
            catch(Exception ex)
            {
                //Display Message if error occurs while reading file
                MessageBox.Show(ex.Message);
            }
        }

        //Create custom method for populating the addon list box
        private void PopulateListBox()
        {
            try //Assure File is readable
            {
                StreamReader inputFile; //Declare StreamReader use for reading file
                addonListBox.Items.Clear(); //Clear items in the combo box
                inputFile = File.OpenText("Options.txt"); //Open file in default folder
                while (!inputFile.EndOfStream) //Verify that more data needs to be read
                {
                    //Read a line and add to list box
                    addonListBox.Items.Add(inputFile.ReadLine());
                }
                inputFile.Close(); //Close input file
            }
            catch (Exception ex)
            {
                //Display Message if error occurs while reading file
                MessageBox.Show(ex.Message);
            }
        }

        //Create custom method for resetting the order form
        private void ResetForm()
        {
            //Clear controls and reset form to original state
            dateMTB.Text = DateTime.Now.ToString("MM/dd/yyyy");
            firstNameTB.Text = "";
            lastNameTB.Text = "";
            phoneNumberMTB.Text = "";
            shippingCB.Checked = false;
            inboardRadioButton.Checked = true;
            addonListBox.ClearSelected();
            firstNameTB.Focus();
        }

        //Create custom method for updating totals
        private void UpdateTotals()
        {
            //Declare variable
            int shippingTF = 0;

            if (shippingCB.Checked==true)
            {
                shippingTF = 1;
            }
            totalPrice = (BOAT_PRICE) + (OPTION_PRICE * addonListBox.SelectedItems.Count) + (DELIVERY_PRICE * shippingTF);
            orderTotalLabel.Text = totalPrice.ToString("c");

        }

                //Create custom method to save the order to an external txt file
                private void SaveForm()
                {
            //If info is not entered display an error and clear the form
            if (firstNameTB.Text == "" || lastNameTB.Text == "" || phoneNumberMTB.Text == "")
            {
                MessageBox.Show("Please enter a valid First name, Last name, and Phone number.", "Information Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ResetForm();
            }

            //if information is all entered
            else

            //Append the order form text to an output txt file and save
            try
            {
                StreamWriter outputFile;
                outputFile = File.AppendText("Orders.txt");
                outputFile.WriteLine("Sunshine Factory Order");
                outputFile.WriteLine("Order Date: " + dateMTB.Text);
                outputFile.WriteLine("Customer Name: " + firstNameTB.Text + " " + lastNameTB.Text);
                outputFile.WriteLine("Phone Number: " + phoneNumberMTB.Text);
                outputFile.WriteLine("Boat Model: " + boatComboBox.Text);
                if (outboardRadioButton.Checked == true)
                {
                    outputFile.WriteLine("Sailboat Style: " + outboardRadioButton.Text);
                }
                else if (inboardRadioButton.Checked == true)
                {
                    outputFile.WriteLine("Sailboat Style: " + inboardRadioButton.Text);
                }
                for(int count=0; count<addonListBox.Items.Count; count++)
                    {
                        if (addonListBox.GetSelected(count))
                        {
                            outputFile.WriteLine("Optionals: " + addonListBox.Items[count]);
                        }
                        
                    }
                
                if (shippingCB.Checked == true)
                {
                    outputFile.WriteLine("Expedited Shipping: YES");
                }
                else if (shippingCB.Checked == false)
                {
                    outputFile.WriteLine("Expedited Shipping: NO");
                }
                outputFile.WriteLine("Total Price: " + orderTotalLabel.Text);
                outputFile.WriteLine();
                outputFile.WriteLine();
                    //close the output file
                outputFile.Close();
                    //reset the form
                ResetForm();
            }
                //show default error message if needed
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

                }

        //Checked chanegd event for shipping check box
        private void shippingCB_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        //Index changed event for addon list box
        private void addonListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        //Save order form click event
        private void saveButton_Click(object sender, EventArgs e)
        {
            SaveForm();
        }

        //Reset order form click event
        private void resetButton_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        //Exit form click event
        private void exitButton_Click(object sender, EventArgs e)
        {
            DialogResult selection;
            selection = MessageBox.Show("Are you sure you wish to exit the program?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(selection==DialogResult.Yes)
            {
                this.Close();
            }


        }
    }
        }

        
        
    
    
   

