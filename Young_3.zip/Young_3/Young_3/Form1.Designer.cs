﻿namespace Young_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.exitButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.addonListBox = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.orderInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.orderTotalLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.shippingOptionLabel = new System.Windows.Forms.Label();
            this.shippingCB = new System.Windows.Forms.CheckBox();
            this.addonLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.outboardRadioButton = new System.Windows.Forms.RadioButton();
            this.inboardRadioButton = new System.Windows.Forms.RadioButton();
            this.boatPriceTB = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.boatComboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateMTB = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.firstNameTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.phoneNumberMTB = new System.Windows.Forms.MaskedTextBox();
            this.lastNameTB = new System.Windows.Forms.TextBox();
            this.customerInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.orderInformationGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.customerInformationGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(359, 521);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 13;
            this.exitButton.Text = "&Exit";
            this.toolTip1.SetToolTip(this.exitButton, "Press this button to exit the form");
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(190, 521);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 12;
            this.resetButton.Text = "&Reset";
            this.toolTip1.SetToolTip(this.resetButton, "Press this button to reset the form");
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(17, 521);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 11;
            this.saveButton.Text = "&Save";
            this.toolTip1.SetToolTip(this.saveButton, "Click this button to save your order");
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // addonListBox
            // 
            this.addonListBox.FormattingEnabled = true;
            this.addonListBox.Location = new System.Drawing.Point(277, 111);
            this.addonListBox.Name = "addonListBox";
            this.addonListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.addonListBox.Size = new System.Drawing.Size(154, 82);
            this.addonListBox.Sorted = true;
            this.addonListBox.TabIndex = 17;
            this.addonListBox.SelectedIndexChanged += new System.EventHandler(this.addonListBox_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(372, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "Per Addon";
            // 
            // orderInformationGroupBox
            // 
            this.orderInformationGroupBox.Controls.Add(this.orderTotalLabel);
            this.orderInformationGroupBox.Controls.Add(this.label13);
            this.orderInformationGroupBox.Controls.Add(this.shippingOptionLabel);
            this.orderInformationGroupBox.Controls.Add(this.shippingCB);
            this.orderInformationGroupBox.Controls.Add(this.addonListBox);
            this.orderInformationGroupBox.Controls.Add(this.label11);
            this.orderInformationGroupBox.Controls.Add(this.addonLabel);
            this.orderInformationGroupBox.Controls.Add(this.label9);
            this.orderInformationGroupBox.Controls.Add(this.label8);
            this.orderInformationGroupBox.Controls.Add(this.outboardRadioButton);
            this.orderInformationGroupBox.Controls.Add(this.inboardRadioButton);
            this.orderInformationGroupBox.Controls.Add(this.boatPriceTB);
            this.orderInformationGroupBox.Controls.Add(this.label7);
            this.orderInformationGroupBox.Controls.Add(this.label6);
            this.orderInformationGroupBox.Controls.Add(this.boatComboBox);
            this.orderInformationGroupBox.Controls.Add(this.label5);
            this.orderInformationGroupBox.Controls.Add(this.dateMTB);
            this.orderInformationGroupBox.Location = new System.Drawing.Point(3, 218);
            this.orderInformationGroupBox.Name = "orderInformationGroupBox";
            this.orderInformationGroupBox.Size = new System.Drawing.Size(444, 283);
            this.orderInformationGroupBox.TabIndex = 10;
            this.orderInformationGroupBox.TabStop = false;
            this.orderInformationGroupBox.Text = "Order Information";
            // 
            // orderTotalLabel
            // 
            this.orderTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orderTotalLabel.Location = new System.Drawing.Point(302, 234);
            this.orderTotalLabel.Name = "orderTotalLabel";
            this.orderTotalLabel.Size = new System.Drawing.Size(100, 23);
            this.orderTotalLabel.TabIndex = 21;
            this.orderTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(298, 210);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 24);
            this.label13.TabIndex = 20;
            this.label13.Text = "Order Total";
            // 
            // shippingOptionLabel
            // 
            this.shippingOptionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shippingOptionLabel.Location = new System.Drawing.Point(6, 210);
            this.shippingOptionLabel.Name = "shippingOptionLabel";
            this.shippingOptionLabel.Size = new System.Drawing.Size(110, 42);
            this.shippingOptionLabel.TabIndex = 19;
            // 
            // shippingCB
            // 
            this.shippingCB.AutoSize = true;
            this.shippingCB.Location = new System.Drawing.Point(6, 255);
            this.shippingCB.Name = "shippingCB";
            this.shippingCB.Size = new System.Drawing.Size(117, 17);
            this.shippingCB.TabIndex = 18;
            this.shippingCB.Text = "Expedited Shipping";
            this.shippingCB.UseVisualStyleBackColor = true;
            this.shippingCB.CheckedChanged += new System.EventHandler(this.shippingCB_CheckedChanged);
            // 
            // addonLabel
            // 
            this.addonLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addonLabel.Location = new System.Drawing.Point(302, 85);
            this.addonLabel.Name = "addonLabel";
            this.addonLabel.Size = new System.Drawing.Size(64, 21);
            this.addonLabel.TabIndex = 15;
            this.addonLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(288, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Additional Addons ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Type of Motor Desired:";
            // 
            // outboardRadioButton
            // 
            this.outboardRadioButton.AutoSize = true;
            this.outboardRadioButton.Location = new System.Drawing.Point(6, 176);
            this.outboardRadioButton.Name = "outboardRadioButton";
            this.outboardRadioButton.Size = new System.Drawing.Size(69, 17);
            this.outboardRadioButton.TabIndex = 7;
            this.outboardRadioButton.TabStop = true;
            this.outboardRadioButton.Text = "Outboard";
            this.outboardRadioButton.UseVisualStyleBackColor = true;
            // 
            // inboardRadioButton
            // 
            this.inboardRadioButton.AutoSize = true;
            this.inboardRadioButton.Location = new System.Drawing.Point(6, 153);
            this.inboardRadioButton.Name = "inboardRadioButton";
            this.inboardRadioButton.Size = new System.Drawing.Size(61, 17);
            this.inboardRadioButton.TabIndex = 6;
            this.inboardRadioButton.TabStop = true;
            this.inboardRadioButton.Text = "Inboard";
            this.inboardRadioButton.UseVisualStyleBackColor = true;
            // 
            // boatPriceTB
            // 
            this.boatPriceTB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.boatPriceTB.Location = new System.Drawing.Point(133, 83);
            this.boatPriceTB.Name = "boatPriceTB";
            this.boatPriceTB.Size = new System.Drawing.Size(76, 21);
            this.boatPriceTB.TabIndex = 5;
            this.boatPriceTB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(143, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Boat Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Type of Boat Desired:";
            // 
            // boatComboBox
            // 
            this.boatComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.boatComboBox.FormattingEnabled = true;
            this.boatComboBox.Location = new System.Drawing.Point(6, 83);
            this.boatComboBox.Name = "boatComboBox";
            this.boatComboBox.Size = new System.Drawing.Size(121, 21);
            this.boatComboBox.Sorted = true;
            this.boatComboBox.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(203, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Today\'s Date";
            // 
            // dateMTB
            // 
            this.dateMTB.Location = new System.Drawing.Point(206, 32);
            this.dateMTB.Mask = "00/00/0000";
            this.dateMTB.Name = "dateMTB";
            this.dateMTB.Size = new System.Drawing.Size(67, 20);
            this.dateMTB.TabIndex = 0;
            this.dateMTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.dateMTB.ValidatingType = typeof(System.DateTime);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "First Name";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Yellow;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 26F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(159, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 89);
            this.label1.TabIndex = 8;
            this.label1.Text = "Sunshine Sailboats Company";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Young_3.Properties.Resources.sailboat;
            this.pictureBox1.Location = new System.Drawing.Point(3, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 127);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // firstNameTB
            // 
            this.firstNameTB.Location = new System.Drawing.Point(6, 47);
            this.firstNameTB.Name = "firstNameTB";
            this.firstNameTB.Size = new System.Drawing.Size(100, 20);
            this.firstNameTB.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(351, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Phone Number";
            // 
            // phoneNumberMTB
            // 
            this.phoneNumberMTB.Location = new System.Drawing.Point(352, 47);
            this.phoneNumberMTB.Mask = "(999) 000-0000";
            this.phoneNumberMTB.Name = "phoneNumberMTB";
            this.phoneNumberMTB.Size = new System.Drawing.Size(77, 20);
            this.phoneNumberMTB.TabIndex = 4;
            this.phoneNumberMTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lastNameTB
            // 
            this.lastNameTB.Location = new System.Drawing.Point(173, 47);
            this.lastNameTB.Name = "lastNameTB";
            this.lastNameTB.Size = new System.Drawing.Size(100, 20);
            this.lastNameTB.TabIndex = 3;
            // 
            // customerInformationGroupBox
            // 
            this.customerInformationGroupBox.Controls.Add(this.label4);
            this.customerInformationGroupBox.Controls.Add(this.phoneNumberMTB);
            this.customerInformationGroupBox.Controls.Add(this.lastNameTB);
            this.customerInformationGroupBox.Controls.Add(this.label3);
            this.customerInformationGroupBox.Controls.Add(this.firstNameTB);
            this.customerInformationGroupBox.Controls.Add(this.label2);
            this.customerInformationGroupBox.Location = new System.Drawing.Point(3, 139);
            this.customerInformationGroupBox.Name = "customerInformationGroupBox";
            this.customerInformationGroupBox.Size = new System.Drawing.Size(444, 73);
            this.customerInformationGroupBox.TabIndex = 9;
            this.customerInformationGroupBox.TabStop = false;
            this.customerInformationGroupBox.Text = "Customer Information";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(195, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Name";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 556);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.orderInformationGroupBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.customerInformationGroupBox);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sunshine Sailboats Company";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.orderInformationGroupBox.ResumeLayout(false);
            this.orderInformationGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.customerInformationGroupBox.ResumeLayout(false);
            this.customerInformationGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.ListBox addonListBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox orderInformationGroupBox;
        private System.Windows.Forms.Label addonLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton outboardRadioButton;
        private System.Windows.Forms.RadioButton inboardRadioButton;
        private System.Windows.Forms.Label boatPriceTB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox boatComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox dateMTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox firstNameTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox phoneNumberMTB;
        private System.Windows.Forms.TextBox lastNameTB;
        private System.Windows.Forms.GroupBox customerInformationGroupBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label shippingOptionLabel;
        private System.Windows.Forms.CheckBox shippingCB;
        private System.Windows.Forms.Label orderTotalLabel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

