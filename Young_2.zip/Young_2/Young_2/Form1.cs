﻿//Programmer: Aaron Young
//Project: Young_2
//Due Date: 10/06/2017
//Description: Individual Assignment #2

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Young_2
{
    public partial class Form1 : Form
    {

        //Declare class-level constants
        private const decimal ORCHESTRA_SEATING_PRICE = 79.95m;
        private const decimal MEZZANINE_SAETING_PRICE = 59.95m;
        private const decimal BALCONY_SEATING_PRICE = 39.95m;
        private const decimal VALET_PARKING_PRICE = 15.00m;
        private const decimal SOUVENIR_PROGRAM_PRICE = 10.00m;
        private const decimal SALES_TAX_RATE = 0.07m;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Set default credit card to visa
            creditCardComboBox.SelectedIndex = 0;

            //Assign prices to labels
            orchestraSeatingPriceLabel.Text = ORCHESTRA_SEATING_PRICE.ToString("c");
            mezzanineSeatingPriceLabel.Text = MEZZANINE_SAETING_PRICE.ToString("c");
            balconySeatingPriceLabel.Text = BALCONY_SEATING_PRICE.ToString("c");
            valetParkingPriceLabel.Text = VALET_PARKING_PRICE.ToString("c");
            souvenirProgramPriceLabel.Text = SOUVENIR_PROGRAM_PRICE.ToString("c");
            salesTaxAmountLabel.Text = SALES_TAX_RATE.ToString("p");
        }

        private void cashRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (cashRadioButton.Checked)
            {
                creditCardComboBox.Enabled = false;
                cardNumberMaskedTextBox.Enabled = false;
                expirationMaskedTextBox.Enabled = false;
                creditCardComboBox.Text = "";
                cardNumberMaskedTextBox.Text = "";
                expirationMaskedTextBox.Text = "";

            }
            else
            {
                creditCardRadioButton.Enabled = true;
                creditCardComboBox.Enabled = true;
                cardNumberMaskedTextBox.Enabled = true;
                expirationMaskedTextBox.Enabled = true;
            }
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare variables
                decimal totalFee = 0.00m;
                int totalTickets = 0;
                decimal salesTax;
                decimal orderTotal;


                //Get total number of tickets
                totalTickets = int.Parse(ticketsDesiredTextBox.Text);

                //Use if statements to calculate total fees
                if (totalTickets < 1 || totalTickets > 4)
                {
                    MessageBox.Show("The number or tickets entered must be between 1 and 4", "Ticket Number Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                if (ticketsDesiredTextBox.Text != "")
                    totalTickets = int.Parse(ticketsDesiredTextBox.Text);

                //Calculations
                if (orchestraSeatingRadioButton.Checked)
                {
                    totalFee += totalTickets * ORCHESTRA_SEATING_PRICE;
                }
                if (mezzanineSeatingRadioButton.Checked)
                {
                    totalFee += totalTickets * MEZZANINE_SAETING_PRICE;
                }
                if (balconySeatingRadioButton.Checked)
                {
                    totalFee += totalTickets * BALCONY_SEATING_PRICE;
                }
                if (valetParkingCheckBox.Checked)
                {
                    totalFee += VALET_PARKING_PRICE;
                }
                if (souvenirProgramCheckBox.Checked)
                {
                    totalFee += SOUVENIR_PROGRAM_PRICE;
                }
                //Display order subtotal
                orderSubtotalLabel.Text = totalFee.ToString("c");

                //Display Sales Tax
                salesTax = totalFee * SALES_TAX_RATE;
                salesTaxTotalLabel.Text = salesTax.ToString("c");

                //Display order total
                orderTotal = totalFee + salesTax;
                orderTotalLabel.Text = orderTotal.ToString("c");

                //Set focus to clear button
                clearButton.Focus();
            }
            catch
            {
                MessageBox.Show("Please Enter a Number Between 1 and 4 in the Amount of Tickets Desired Text Box", "Ticket Amount Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //Show error message if card number and expiration is not entered when credit card radio button is enabled
            if (cardNumberMaskedTextBox.MaskCompleted == false && cardNumberMaskedTextBox.Enabled == true)
                MessageBox.Show("Please Enter a Valid Credit Card Number", "Credit Card Number Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (expirationMaskedTextBox.MaskCompleted == false && expirationMaskedTextBox.Enabled == true)
                MessageBox.Show("Please Enter Your Credit Card's Expiration Date", "Credit Card Expiration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ticketsDesiredTextBox.Text = "";
            orderSubtotalLabel.Text = "";
            salesTaxTotalLabel.Text = "";
            orderTotalLabel.Text = "";
            titleComboBox.Text = "";
            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            streetTextBox.Text = "";
            cityTextBox.Text = "";
            stateMaskedTextBox.Text = "";
            zipCodeMaskedTextBox.Text = "";
            phoneNumberMaskedTextBox.Text = "";
            orchestraSeatingRadioButton.Checked = false;
            mezzanineSeatingRadioButton.Checked = false;
            balconySeatingRadioButton.Checked = false;
            valetParkingCheckBox.Checked = false;
            souvenirProgramCheckBox.Checked = false;
            cashRadioButton.Checked = true;

            //set focus
            titleComboBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            DialogResult selection;
            selection = MessageBox.Show("Are you sure you wish to exit the program?", "Program Exit Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);

            //take action based on button pressed
            if (selection == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
