﻿namespace Young_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.orchestraSeatingPriceLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.salesTaxAmountLabel = new System.Windows.Forms.Label();
            this.souvenirProgramPriceLabel = new System.Windows.Forms.Label();
            this.valetParkingPriceLabel = new System.Windows.Forms.Label();
            this.balconySeatingPriceLabel = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.willCallRadioButton = new System.Windows.Forms.RadioButton();
            this.deliveryByMailRadioButton = new System.Windows.Forms.RadioButton();
            this.paymentInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.expirationMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.cardNumberMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.creditCardComboBox = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.creditCardRadioButton = new System.Windows.Forms.RadioButton();
            this.cashRadioButton = new System.Windows.Forms.RadioButton();
            this.deliveryInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.mezzanineSeatingPriceLabel = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label15 = new System.Windows.Forms.Label();
            this.customerInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.phoneNumberMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.zipCodeMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.stateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.streetTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.titleComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.purchaseInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.orderTotalLabel = new System.Windows.Forms.Label();
            this.salesTaxTotalLabel = new System.Windows.Forms.Label();
            this.orderSubtotalLabel = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.mezzanineSeatingRadioButton = new System.Windows.Forms.RadioButton();
            this.souvenirProgramCheckBox = new System.Windows.Forms.CheckBox();
            this.valetParkingCheckBox = new System.Windows.Forms.CheckBox();
            this.balconySeatingRadioButton = new System.Windows.Forms.RadioButton();
            this.orchestraSeatingRadioButton = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.ticketsDesiredTextBox = new System.Windows.Forms.TextBox();
            this.paymentInfoGroupBox.SuspendLayout();
            this.deliveryInfoGroupBox.SuspendLayout();
            this.customerInfoGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.purchaseInfoGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // orchestraSeatingPriceLabel
            // 
            this.orchestraSeatingPriceLabel.AutoSize = true;
            this.orchestraSeatingPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orchestraSeatingPriceLabel.Location = new System.Drawing.Point(153, 62);
            this.orchestraSeatingPriceLabel.Name = "orchestraSeatingPriceLabel";
            this.orchestraSeatingPriceLabel.Size = new System.Drawing.Size(2, 15);
            this.orchestraSeatingPriceLabel.TabIndex = 1;
            this.orchestraSeatingPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(481, 474);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(103, 81);
            this.clearButton.TabIndex = 16;
            this.clearButton.Text = "C&lear";
            this.toolTip1.SetToolTip(this.clearButton, "Press this button to clear the form.");
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(277, 474);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(108, 81);
            this.calculateButton.TabIndex = 15;
            this.calculateButton.Text = "&Calculate";
            this.toolTip1.SetToolTip(this.calculateButton, "Press this button to calculate your order total.");
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // salesTaxAmountLabel
            // 
            this.salesTaxAmountLabel.AutoSize = true;
            this.salesTaxAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesTaxAmountLabel.Location = new System.Drawing.Point(203, 212);
            this.salesTaxAmountLabel.Name = "salesTaxAmountLabel";
            this.salesTaxAmountLabel.Size = new System.Drawing.Size(2, 15);
            this.salesTaxAmountLabel.TabIndex = 20;
            this.salesTaxAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // souvenirProgramPriceLabel
            // 
            this.souvenirProgramPriceLabel.AutoSize = true;
            this.souvenirProgramPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.souvenirProgramPriceLabel.Location = new System.Drawing.Point(153, 186);
            this.souvenirProgramPriceLabel.Name = "souvenirProgramPriceLabel";
            this.souvenirProgramPriceLabel.Size = new System.Drawing.Size(2, 15);
            this.souvenirProgramPriceLabel.TabIndex = 5;
            this.souvenirProgramPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // valetParkingPriceLabel
            // 
            this.valetParkingPriceLabel.AutoSize = true;
            this.valetParkingPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.valetParkingPriceLabel.Location = new System.Drawing.Point(153, 163);
            this.valetParkingPriceLabel.Name = "valetParkingPriceLabel";
            this.valetParkingPriceLabel.Size = new System.Drawing.Size(2, 15);
            this.valetParkingPriceLabel.TabIndex = 4;
            this.valetParkingPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // balconySeatingPriceLabel
            // 
            this.balconySeatingPriceLabel.AutoSize = true;
            this.balconySeatingPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.balconySeatingPriceLabel.Location = new System.Drawing.Point(153, 125);
            this.balconySeatingPriceLabel.Name = "balconySeatingPriceLabel";
            this.balconySeatingPriceLabel.Size = new System.Drawing.Size(2, 15);
            this.balconySeatingPriceLabel.TabIndex = 3;
            this.balconySeatingPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(94, 265);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 13);
            this.label17.TabIndex = 14;
            this.label17.Text = "Order Total";
            // 
            // taxLabel
            // 
            this.taxLabel.AutoSize = true;
            this.taxLabel.Location = new System.Drawing.Point(143, 214);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(54, 13);
            this.taxLabel.TabIndex = 13;
            this.taxLabel.Text = "Sales Tax";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(683, 474);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(102, 81);
            this.exitButton.TabIndex = 17;
            this.exitButton.Text = "&Exit";
            this.toolTip1.SetToolTip(this.exitButton, "Press this button to exit the form.");
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(19, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(115, 40);
            this.label18.TabIndex = 2;
            this.label18.Text = "How would you like to recieve your tickets?";
            // 
            // willCallRadioButton
            // 
            this.willCallRadioButton.AutoSize = true;
            this.willCallRadioButton.Location = new System.Drawing.Point(22, 100);
            this.willCallRadioButton.Name = "willCallRadioButton";
            this.willCallRadioButton.Size = new System.Drawing.Size(62, 17);
            this.willCallRadioButton.TabIndex = 1;
            this.willCallRadioButton.Text = "Will Call";
            this.willCallRadioButton.UseVisualStyleBackColor = true;
            // 
            // deliveryByMailRadioButton
            // 
            this.deliveryByMailRadioButton.AutoSize = true;
            this.deliveryByMailRadioButton.Checked = true;
            this.deliveryByMailRadioButton.Location = new System.Drawing.Point(22, 77);
            this.deliveryByMailRadioButton.Name = "deliveryByMailRadioButton";
            this.deliveryByMailRadioButton.Size = new System.Drawing.Size(99, 17);
            this.deliveryByMailRadioButton.TabIndex = 0;
            this.deliveryByMailRadioButton.TabStop = true;
            this.deliveryByMailRadioButton.Text = "Delivery by Mail";
            this.deliveryByMailRadioButton.UseVisualStyleBackColor = true;
            // 
            // paymentInfoGroupBox
            // 
            this.paymentInfoGroupBox.Controls.Add(this.label22);
            this.paymentInfoGroupBox.Controls.Add(this.label21);
            this.paymentInfoGroupBox.Controls.Add(this.label20);
            this.paymentInfoGroupBox.Controls.Add(this.expirationMaskedTextBox);
            this.paymentInfoGroupBox.Controls.Add(this.cardNumberMaskedTextBox);
            this.paymentInfoGroupBox.Controls.Add(this.creditCardComboBox);
            this.paymentInfoGroupBox.Controls.Add(this.label19);
            this.paymentInfoGroupBox.Controls.Add(this.creditCardRadioButton);
            this.paymentInfoGroupBox.Controls.Add(this.cashRadioButton);
            this.paymentInfoGroupBox.Location = new System.Drawing.Point(461, 262);
            this.paymentInfoGroupBox.Name = "paymentInfoGroupBox";
            this.paymentInfoGroupBox.Size = new System.Drawing.Size(356, 179);
            this.paymentInfoGroupBox.TabIndex = 14;
            this.paymentInfoGroupBox.TabStop = false;
            this.paymentInfoGroupBox.Text = "Payment Information";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(210, 121);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(94, 13);
            this.label22.TabIndex = 8;
            this.label22.Text = "Expiration Date";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(6, 119);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(117, 13);
            this.label21.TabIndex = 7;
            this.label21.Text = "Credit Card Number";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(137, 78);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(117, 13);
            this.label20.TabIndex = 6;
            this.label20.Text = "Type of Credit Card";
            // 
            // expirationMaskedTextBox
            // 
            this.expirationMaskedTextBox.Enabled = false;
            this.expirationMaskedTextBox.Location = new System.Drawing.Point(225, 137);
            this.expirationMaskedTextBox.Mask = "00/00/0000";
            this.expirationMaskedTextBox.Name = "expirationMaskedTextBox";
            this.expirationMaskedTextBox.Size = new System.Drawing.Size(64, 20);
            this.expirationMaskedTextBox.TabIndex = 5;
            this.expirationMaskedTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // cardNumberMaskedTextBox
            // 
            this.cardNumberMaskedTextBox.Enabled = false;
            this.cardNumberMaskedTextBox.Location = new System.Drawing.Point(9, 135);
            this.cardNumberMaskedTextBox.Mask = "0000 0000 0000 0000";
            this.cardNumberMaskedTextBox.Name = "cardNumberMaskedTextBox";
            this.cardNumberMaskedTextBox.Size = new System.Drawing.Size(114, 20);
            this.cardNumberMaskedTextBox.TabIndex = 4;
            // 
            // creditCardComboBox
            // 
            this.creditCardComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.creditCardComboBox.Enabled = false;
            this.creditCardComboBox.FormattingEnabled = true;
            this.creditCardComboBox.Items.AddRange(new object[] {
            "Visa",
            "American Express",
            "Discover",
            "MasterCard"});
            this.creditCardComboBox.Location = new System.Drawing.Point(140, 93);
            this.creditCardComboBox.Name = "creditCardComboBox";
            this.creditCardComboBox.Size = new System.Drawing.Size(121, 21);
            this.creditCardComboBox.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 31);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(96, 13);
            this.label19.TabIndex = 2;
            this.label19.Text = "Payment Option";
            // 
            // creditCardRadioButton
            // 
            this.creditCardRadioButton.AutoSize = true;
            this.creditCardRadioButton.Location = new System.Drawing.Point(9, 74);
            this.creditCardRadioButton.Name = "creditCardRadioButton";
            this.creditCardRadioButton.Size = new System.Drawing.Size(77, 17);
            this.creditCardRadioButton.TabIndex = 1;
            this.creditCardRadioButton.TabStop = true;
            this.creditCardRadioButton.Text = "Credit Card";
            this.creditCardRadioButton.UseVisualStyleBackColor = true;
            // 
            // cashRadioButton
            // 
            this.cashRadioButton.AutoSize = true;
            this.cashRadioButton.Checked = true;
            this.cashRadioButton.Location = new System.Drawing.Point(9, 51);
            this.cashRadioButton.Name = "cashRadioButton";
            this.cashRadioButton.Size = new System.Drawing.Size(49, 17);
            this.cashRadioButton.TabIndex = 0;
            this.cashRadioButton.TabStop = true;
            this.cashRadioButton.Text = "Cash";
            this.cashRadioButton.UseVisualStyleBackColor = true;
            this.cashRadioButton.CheckedChanged += new System.EventHandler(this.cashRadioButton_CheckedChanged);
            // 
            // deliveryInfoGroupBox
            // 
            this.deliveryInfoGroupBox.Controls.Add(this.label18);
            this.deliveryInfoGroupBox.Controls.Add(this.willCallRadioButton);
            this.deliveryInfoGroupBox.Controls.Add(this.deliveryByMailRadioButton);
            this.deliveryInfoGroupBox.Location = new System.Drawing.Point(255, 262);
            this.deliveryInfoGroupBox.Name = "deliveryInfoGroupBox";
            this.deliveryInfoGroupBox.Size = new System.Drawing.Size(200, 123);
            this.deliveryInfoGroupBox.TabIndex = 13;
            this.deliveryInfoGroupBox.TabStop = false;
            this.deliveryInfoGroupBox.Text = "Delivery Information";
            // 
            // mezzanineSeatingPriceLabel
            // 
            this.mezzanineSeatingPriceLabel.AutoSize = true;
            this.mezzanineSeatingPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mezzanineSeatingPriceLabel.Location = new System.Drawing.Point(153, 94);
            this.mezzanineSeatingPriceLabel.Name = "mezzanineSeatingPriceLabel";
            this.mezzanineSeatingPriceLabel.Size = new System.Drawing.Size(2, 15);
            this.mezzanineSeatingPriceLabel.TabIndex = 2;
            this.mezzanineSeatingPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 214);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "Order Subtotal";
            // 
            // customerInfoGroupBox
            // 
            this.customerInfoGroupBox.Controls.Add(this.label9);
            this.customerInfoGroupBox.Controls.Add(this.label8);
            this.customerInfoGroupBox.Controls.Add(this.label7);
            this.customerInfoGroupBox.Controls.Add(this.label6);
            this.customerInfoGroupBox.Controls.Add(this.label5);
            this.customerInfoGroupBox.Controls.Add(this.label4);
            this.customerInfoGroupBox.Controls.Add(this.label3);
            this.customerInfoGroupBox.Controls.Add(this.label2);
            this.customerInfoGroupBox.Controls.Add(this.phoneNumberMaskedTextBox);
            this.customerInfoGroupBox.Controls.Add(this.zipCodeMaskedTextBox);
            this.customerInfoGroupBox.Controls.Add(this.stateMaskedTextBox);
            this.customerInfoGroupBox.Controls.Add(this.cityTextBox);
            this.customerInfoGroupBox.Controls.Add(this.streetTextBox);
            this.customerInfoGroupBox.Controls.Add(this.lastNameTextBox);
            this.customerInfoGroupBox.Controls.Add(this.firstNameTextBox);
            this.customerInfoGroupBox.Controls.Add(this.titleComboBox);
            this.customerInfoGroupBox.Location = new System.Drawing.Point(246, 45);
            this.customerInfoGroupBox.Name = "customerInfoGroupBox";
            this.customerInfoGroupBox.Size = new System.Drawing.Size(571, 211);
            this.customerInfoGroupBox.TabIndex = 11;
            this.customerInfoGroupBox.TabStop = false;
            this.customerInfoGroupBox.Text = "Customer Information";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(416, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Phone Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(265, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Zip Code";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(135, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "State";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(74, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "City";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(282, 79);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Street";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(396, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(170, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Title";
            // 
            // phoneNumberMaskedTextBox
            // 
            this.phoneNumberMaskedTextBox.Location = new System.Drawing.Point(415, 167);
            this.phoneNumberMaskedTextBox.Mask = "(999) 000-0000";
            this.phoneNumberMaskedTextBox.Name = "phoneNumberMaskedTextBox";
            this.phoneNumberMaskedTextBox.Size = new System.Drawing.Size(79, 20);
            this.phoneNumberMaskedTextBox.TabIndex = 7;
            // 
            // zipCodeMaskedTextBox
            // 
            this.zipCodeMaskedTextBox.Location = new System.Drawing.Point(268, 171);
            this.zipCodeMaskedTextBox.Mask = "00000";
            this.zipCodeMaskedTextBox.Name = "zipCodeMaskedTextBox";
            this.zipCodeMaskedTextBox.Size = new System.Drawing.Size(36, 20);
            this.zipCodeMaskedTextBox.TabIndex = 6;
            this.zipCodeMaskedTextBox.ValidatingType = typeof(int);
            // 
            // stateMaskedTextBox
            // 
            this.stateMaskedTextBox.Location = new System.Drawing.Point(138, 171);
            this.stateMaskedTextBox.Mask = ">&&";
            this.stateMaskedTextBox.Name = "stateMaskedTextBox";
            this.stateMaskedTextBox.Size = new System.Drawing.Size(21, 20);
            this.stateMaskedTextBox.TabIndex = 5;
            // 
            // cityTextBox
            // 
            this.cityTextBox.Location = new System.Drawing.Point(32, 171);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(100, 20);
            this.cityTextBox.TabIndex = 4;
            // 
            // streetTextBox
            // 
            this.streetTextBox.Location = new System.Drawing.Point(31, 95);
            this.streetTextBox.Name = "streetTextBox";
            this.streetTextBox.Size = new System.Drawing.Size(508, 20);
            this.streetTextBox.TabIndex = 3;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(306, 40);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(233, 20);
            this.lastNameTextBox.TabIndex = 2;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(100, 40);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(200, 20);
            this.firstNameTextBox.TabIndex = 1;
            // 
            // titleComboBox
            // 
            this.titleComboBox.FormattingEnabled = true;
            this.titleComboBox.Items.AddRange(new object[] {
            "Dr.",
            "Mr.",
            "Mrs.",
            "Ms."});
            this.titleComboBox.Location = new System.Drawing.Point(31, 40);
            this.titleComboBox.Name = "titleComboBox";
            this.titleComboBox.Size = new System.Drawing.Size(54, 21);
            this.titleComboBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Aqua;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(313, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(437, 39);
            this.label1.TabIndex = 10;
            this.label1.Text = "Apex Symphony Annual Gala";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Young_2.Properties.Resources.classmusic;
            this.pictureBox1.Location = new System.Drawing.Point(4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(236, 253);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // purchaseInfoGroupBox
            // 
            this.purchaseInfoGroupBox.Controls.Add(this.salesTaxAmountLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.souvenirProgramPriceLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.valetParkingPriceLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.balconySeatingPriceLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.mezzanineSeatingPriceLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.orchestraSeatingPriceLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.label17);
            this.purchaseInfoGroupBox.Controls.Add(this.taxLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.label15);
            this.purchaseInfoGroupBox.Controls.Add(this.orderTotalLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.salesTaxTotalLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.orderSubtotalLabel);
            this.purchaseInfoGroupBox.Controls.Add(this.label11);
            this.purchaseInfoGroupBox.Controls.Add(this.mezzanineSeatingRadioButton);
            this.purchaseInfoGroupBox.Controls.Add(this.souvenirProgramCheckBox);
            this.purchaseInfoGroupBox.Controls.Add(this.valetParkingCheckBox);
            this.purchaseInfoGroupBox.Controls.Add(this.balconySeatingRadioButton);
            this.purchaseInfoGroupBox.Controls.Add(this.orchestraSeatingRadioButton);
            this.purchaseInfoGroupBox.Controls.Add(this.label10);
            this.purchaseInfoGroupBox.Controls.Add(this.ticketsDesiredTextBox);
            this.purchaseInfoGroupBox.Location = new System.Drawing.Point(4, 262);
            this.purchaseInfoGroupBox.Name = "purchaseInfoGroupBox";
            this.purchaseInfoGroupBox.Size = new System.Drawing.Size(246, 303);
            this.purchaseInfoGroupBox.TabIndex = 12;
            this.purchaseInfoGroupBox.TabStop = false;
            this.purchaseInfoGroupBox.Text = "Purchase Information";
            // 
            // orderTotalLabel
            // 
            this.orderTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orderTotalLabel.Location = new System.Drawing.Point(75, 278);
            this.orderTotalLabel.Name = "orderTotalLabel";
            this.orderTotalLabel.Size = new System.Drawing.Size(100, 23);
            this.orderTotalLabel.TabIndex = 8;
            this.orderTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // salesTaxTotalLabel
            // 
            this.salesTaxTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesTaxTotalLabel.Location = new System.Drawing.Point(140, 227);
            this.salesTaxTotalLabel.Name = "salesTaxTotalLabel";
            this.salesTaxTotalLabel.Size = new System.Drawing.Size(106, 23);
            this.salesTaxTotalLabel.TabIndex = 7;
            this.salesTaxTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // orderSubtotalLabel
            // 
            this.orderSubtotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orderSubtotalLabel.Location = new System.Drawing.Point(0, 227);
            this.orderSubtotalLabel.Name = "orderSubtotalLabel";
            this.orderSubtotalLabel.Size = new System.Drawing.Size(106, 23);
            this.orderSubtotalLabel.TabIndex = 6;
            this.orderSubtotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(72, 146);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 13);
            this.label11.TabIndex = 8;
            this.label11.Text = "Optionals";
            // 
            // mezzanineSeatingRadioButton
            // 
            this.mezzanineSeatingRadioButton.AutoSize = true;
            this.mezzanineSeatingRadioButton.Location = new System.Drawing.Point(34, 92);
            this.mezzanineSeatingRadioButton.Name = "mezzanineSeatingRadioButton";
            this.mezzanineSeatingRadioButton.Size = new System.Drawing.Size(115, 17);
            this.mezzanineSeatingRadioButton.TabIndex = 7;
            this.mezzanineSeatingRadioButton.TabStop = true;
            this.mezzanineSeatingRadioButton.Text = "Mezzanine Seating";
            this.mezzanineSeatingRadioButton.UseVisualStyleBackColor = true;
            // 
            // souvenirProgramCheckBox
            // 
            this.souvenirProgramCheckBox.AutoSize = true;
            this.souvenirProgramCheckBox.Location = new System.Drawing.Point(34, 184);
            this.souvenirProgramCheckBox.Name = "souvenirProgramCheckBox";
            this.souvenirProgramCheckBox.Size = new System.Drawing.Size(110, 17);
            this.souvenirProgramCheckBox.TabIndex = 6;
            this.souvenirProgramCheckBox.Text = "Souvenir Program";
            this.souvenirProgramCheckBox.UseVisualStyleBackColor = true;
            // 
            // valetParkingCheckBox
            // 
            this.valetParkingCheckBox.AutoSize = true;
            this.valetParkingCheckBox.Location = new System.Drawing.Point(34, 161);
            this.valetParkingCheckBox.Name = "valetParkingCheckBox";
            this.valetParkingCheckBox.Size = new System.Drawing.Size(115, 17);
            this.valetParkingCheckBox.TabIndex = 5;
            this.valetParkingCheckBox.Text = "Valet Parking Pass";
            this.valetParkingCheckBox.UseVisualStyleBackColor = true;
            // 
            // balconySeatingRadioButton
            // 
            this.balconySeatingRadioButton.AutoSize = true;
            this.balconySeatingRadioButton.Location = new System.Drawing.Point(34, 123);
            this.balconySeatingRadioButton.Name = "balconySeatingRadioButton";
            this.balconySeatingRadioButton.Size = new System.Drawing.Size(102, 17);
            this.balconySeatingRadioButton.TabIndex = 4;
            this.balconySeatingRadioButton.TabStop = true;
            this.balconySeatingRadioButton.Text = "Balcony Seating";
            this.balconySeatingRadioButton.UseVisualStyleBackColor = true;
            // 
            // orchestraSeatingRadioButton
            // 
            this.orchestraSeatingRadioButton.AutoSize = true;
            this.orchestraSeatingRadioButton.Location = new System.Drawing.Point(34, 60);
            this.orchestraSeatingRadioButton.Name = "orchestraSeatingRadioButton";
            this.orchestraSeatingRadioButton.Size = new System.Drawing.Size(110, 17);
            this.orchestraSeatingRadioButton.TabIndex = 2;
            this.orchestraSeatingRadioButton.TabStop = true;
            this.orchestraSeatingRadioButton.Text = "Orchestra Seating";
            this.orchestraSeatingRadioButton.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 52);
            this.label10.TabIndex = 1;
            this.label10.Text = "Number of Tickets Desired (Max of 4)";
            // 
            // ticketsDesiredTextBox
            // 
            this.ticketsDesiredTextBox.Location = new System.Drawing.Point(112, 24);
            this.ticketsDesiredTextBox.Name = "ticketsDesiredTextBox";
            this.ticketsDesiredTextBox.Size = new System.Drawing.Size(39, 20);
            this.ticketsDesiredTextBox.TabIndex = 0;
            this.ticketsDesiredTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 568);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.paymentInfoGroupBox);
            this.Controls.Add(this.deliveryInfoGroupBox);
            this.Controls.Add(this.customerInfoGroupBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.purchaseInfoGroupBox);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Apex Symphony Annual Gala Ticket Order Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.paymentInfoGroupBox.ResumeLayout(false);
            this.paymentInfoGroupBox.PerformLayout();
            this.deliveryInfoGroupBox.ResumeLayout(false);
            this.deliveryInfoGroupBox.PerformLayout();
            this.customerInfoGroupBox.ResumeLayout(false);
            this.customerInfoGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.purchaseInfoGroupBox.ResumeLayout(false);
            this.purchaseInfoGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label orchestraSeatingPriceLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label salesTaxAmountLabel;
        private System.Windows.Forms.Label souvenirProgramPriceLabel;
        private System.Windows.Forms.Label valetParkingPriceLabel;
        private System.Windows.Forms.Label balconySeatingPriceLabel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RadioButton willCallRadioButton;
        private System.Windows.Forms.RadioButton deliveryByMailRadioButton;
        private System.Windows.Forms.GroupBox paymentInfoGroupBox;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.MaskedTextBox expirationMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox cardNumberMaskedTextBox;
        private System.Windows.Forms.ComboBox creditCardComboBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RadioButton creditCardRadioButton;
        private System.Windows.Forms.RadioButton cashRadioButton;
        private System.Windows.Forms.GroupBox deliveryInfoGroupBox;
        private System.Windows.Forms.Label mezzanineSeatingPriceLabel;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox customerInfoGroupBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox phoneNumberMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox zipCodeMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox stateMaskedTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox streetTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.ComboBox titleComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox purchaseInfoGroupBox;
        private System.Windows.Forms.Label orderTotalLabel;
        private System.Windows.Forms.Label salesTaxTotalLabel;
        private System.Windows.Forms.Label orderSubtotalLabel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton mezzanineSeatingRadioButton;
        private System.Windows.Forms.CheckBox souvenirProgramCheckBox;
        private System.Windows.Forms.CheckBox valetParkingCheckBox;
        private System.Windows.Forms.RadioButton balconySeatingRadioButton;
        private System.Windows.Forms.RadioButton orchestraSeatingRadioButton;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox ticketsDesiredTextBox;
    }
}

